function [ammanSectionMatrix] = TheAmmanSectionMatrix(LimitingValue)
%Fadi Al-Ghawanmeh April 10, 2023
% create sectionMatrix that include, for each participant, the average
% movement persection

%  start=1; theEnd=4099;  disp('sec.0')
%  start=4100; theEnd=17100;  disp('sec.1')
% start=17300; theEnd=30300;  disp('sec.2')   
%  start=30400; theEnd=42300;  disp('sec.3')
% start=42700; theEnd=48600;  disp('sec.4')   
% start=48700; theEnd=52060;  disp('sec.5')   
% start=3100; theEnd=48600;  disp('all improvisation')      


Matrices=load('C:\Users\fadig\Desktop\main experiment Oslo\Oslo clean signals\background detection\IntensityLimited3AmmanMatrixDenoised5_new_and_Oslo.mat');
RawAmmanMatrix=Matrices.IntensityLimited3AmmanMatrixDenoised5_new;
%RawOsloMatrix=Matrices.IntensityLimited3OsloMatrixDenoised5_new(start:theEnd,:);

AmmanMatrix=LimitIntensitiesInMatrix(RawAmmanMatrix, LimitingValue);

for i=1:30
        ammanSectionMatrix(1,i)= mean(AmmanMatrix(1:4099,i));
        ammanSectionMatrix(2,i)= mean(AmmanMatrix(4100:17100,i));
        ammanSectionMatrix(3,i)= mean(AmmanMatrix(17300:30300,i));
        ammanSectionMatrix(4,i)= mean(AmmanMatrix(30400:42300,i));
        ammanSectionMatrix(5,i)= mean(AmmanMatrix(42700:48600,i));
        ammanSectionMatrix(6,i)= mean(AmmanMatrix(48700:52060,i));
        ammanSectionMatrix(7,i)= mean(AmmanMatrix(3100:48600,i));
end


end

