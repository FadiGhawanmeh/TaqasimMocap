function [VectorNormalizedMatrix]= NormalizeVectorsInMatrix(Matrix)
% By Fadi AL-Ghawanmeh on July 18, 2022
% Matrix is the mocap vectors matrix: each vector in a colomn 
% this function is better applied after applying LimitIntensitiesInMatrix

VectorNormalizedMatrix=Matrix;

[rows columns]=size(VectorNormalizedMatrix);


for i=1:columns
    
VectorNormalizedMatrix(:,i)= VectorNormalizedMatrix(:,i)/max(VectorNormalizedMatrix(:,i));

end


