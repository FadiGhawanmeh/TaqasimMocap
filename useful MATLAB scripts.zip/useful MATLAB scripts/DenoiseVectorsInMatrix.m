function [DenoisedMatrix]= DenoiseVectorsInMatrix(Matrix, NoiseLevel)
% By Fadi AL-Ghawanmeh on Oct. 10, 2022

DenoisedMatrix=Matrix;

[rows columns]=size(DenoisedMatrix);


for i=1:columns
 
    %denoise(noise in the slide ranges usually between .25 and 0.75, mostly .5)
    DenoisedMatrix(:,i)=DenoisedMatrix(:,i)- NoiseLevel;
    for j=1:rows
    if DenoisedMatrix(j,i)<0 
        DenoisedMatrix(j,i)=0;
    end
    end
    
    %mormalize
%DenoisedMatrix(:,i)= DenoisedMatrix(:,i)/max(DenoisedMatrix(:,i));

end


