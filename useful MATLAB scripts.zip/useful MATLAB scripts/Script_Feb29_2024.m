%% Start by opening the file: Amman signals struct33 and matrix33

%AmmanMatrix33
 %33 means the matrix is not clean. Samples 5, 29,32 will be rejected later.
%clean matric

%AmmanMatrix=myOsloMatrix';

AmmanMatrix=AmmanMatrix33';
AmmanMatrix(32,:)=[];  
AmmanMatrix(29,:)=[];  
AmmanMatrix(5,:)=[];



IntensityLimitedMatrix_AmmanMatrix= LimitIntensitiesInMatrix(AmmanMatrix,3);

% VectorNormalizedMatrix_AmmanMatrix= NormalizeVectorsInMatrix(IntensityLimitedMatrix_AmmanMatrix);
VectorNormalizedMatrix_AmmanMatrix=IntensityLimitedMatrix_AmmanMatrix;

%before applying the following... comment the "normalize" part
DenoisedAndNormalizedMatrix_AmmanMatrix= DenoiseAndNormalizeVectorsInMatrix(VectorNormalizedMatrix_AmmanMatrix, 0.25);

% figure
% subplot(4,1,1)
% imagesc(1:52060,1:30,AmmanMatrix');
% subplot(4,1,2)
% imagesc(1:52060,1:30,IntensityLimitedMatrix_AmmanMatrix');
% subplot(4,1,3)
% imagesc(1:52060,1:30,VectorNormalizedMatrix_AmmanMatrix');
% subplot(4,1,4)
% imagesc(1:52060,1:30,DenoisedAndNormalizedMatrix_AmmanMatrix');



%imagesc(1:52060,1:30,AmmanMatrix');
%imagesc(1:52060,1:30,IntensityLimitedMatrix_AmmanMatrix');
%imagesc(1:52060,1:30,VectorNormalizedMatrix_AmmanMatrix');
%imagesc(1:52060,1:30,DenoisedAndNormalizedMatrix_AmmanMatrix');


sizer =size(AmmanMatrix);

for i=1: sizer(1,1)
    % ammanMeansArray(i)= mean(myAmmanMatrix(i,:));
    % osloMeansArray(i)= mean(myOsloMatrix(i,:));

   AmmanMeansArray(i)= mean(DenoisedAndNormalizedMatrix_AmmanMatrix(i,:));
end


