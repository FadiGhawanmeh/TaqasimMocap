function [IntensityLimitedMatrix]= LimitIntensitiesInMatrix(Matrix,cap)
% By Fadi AL-Ghawanmeh on July 17, 2022
% Matrix is the mocap vectors matrix: each vector in a colomn 
% cap is the intensity limit

IntensityLimitedMatrix=Matrix;

[rows columns]=size(IntensityLimitedMatrix);


for i=1:columns
    
    for j=1:rows
       
        if IntensityLimitedMatrix(j,i)>cap
           IntensityLimitedMatrix(j,i)=cap;
        end
    end 

end


