function [complexityVec] = getComplexityVector

nmatStruct=load('ElicitAdjustedNmat.mat');
%get the adjusted nmat  (after fixing the issue with midi tempo)
nmat= nmatStruct.adjustednmat;

%get only the upper line (melody)
nmat = extreme(nmat,'high'); 

window=15;%10;
step=2;%5;
k=1;  % counter for complexityVec

start=40; % no notes before this time in my elicit. If I start from 0 complebm complains
ending= 489.99;   %it complains when the content is empty (Silence). so hard code it to last real note in the elicit
%LengthofComplexityVec= nmat(length(nmat),6)+ nmat(length(nmat),7);

for i=start:step:ending
complexityVec(k)= complebm(onsetwindow(nmat,i,i+window,'sec'), 'o');
k=k+1;
end

