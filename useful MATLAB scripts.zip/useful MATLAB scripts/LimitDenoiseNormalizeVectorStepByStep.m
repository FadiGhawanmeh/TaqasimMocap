figure
StartCrop=0;
EndCrop=520;

%before anything
subplot(4,1,1)
imagesc(floor(StartCrop*100)+1:floor(EndCrop*100),1:33,AmmanMatrix33');

%limit
AmmanLimited=LimitIntensitiesInMatrix(AmmanMatrix33,3);
subplot(4,1,2)
imagesc(floor(StartCrop*100)+1:floor(EndCrop*100),1:33,AmmanLimited');

%denoise
AmmanLimitedDenoised=DenoiseVectorsInMatrix(AmmanLimited, 0.5);
subplot(4,1,3)
imagesc(floor(StartCrop*100)+1:floor(EndCrop*100),1:33,AmmanLimitedDenoised');

%normalize
AmmanLimitedDenoisedNormalized=NormalizeVectorsInMatrix(AmmanLimitedDenoised);
subplot(4,1,4)
imagesc(floor(StartCrop*100)+1:floor(EndCrop*100),1:33,AmmanLimitedDenoisedNormalized');


