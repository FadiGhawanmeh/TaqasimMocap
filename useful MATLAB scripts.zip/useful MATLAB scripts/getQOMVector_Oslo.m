function [QOMVector_Oslo] = getQOMVector_Oslo
%Fadi Al-Ghawanmeh August 14,2022

%get quantity of motion vector for all participants in Oslo using
%AllParticipantsQOM victor. The quantity of motion vector is calculated on
%a "window" that is moving by a "step".

%for the silence at the end (490-520).
%create its own  QOM elements. you may take it each 5 seconds, then
%smooth the whole period to 10 second.

% answers
window=20;%10;
step=2;%15;%5;
k=1;  % counter for registerVec
%start and end in seconds
start=     0;
ending= 520;%489.99; 
PreviouslySavedWorkspace=load('IntenstyLimited3OsloMatrixDenoised50.mat');%previously saved workspace
%crop preparation
CroppedIntensistyLimited3OsloMatrixDenoised50=PreviouslySavedWorkspace.IntensistyLimited3OsloMatrixDenoised50(floor(start*100)+1:floor(ending*100),:);
ComulativeParticipantsVector = AllParticipantsQOM(CroppedIntensistyLimited3OsloMatrixDenoised50);
%smooth the signal
 SmoothedComulativeParticipantsVector=movavg(ComulativeParticipantsVector,'simple',50) ;

 %LengthOfSmoothedComulativeParticipantsVector= length(SmoothedComulativeParticipantsVector)
  
 for i=start:step:(ending-window) 
   %  floor((i+window)*100)
    QOMVector_Oslo(k)= mean(SmoothedComulativeParticipantsVector(floor(i*100)+1:  floor((i+window)*100)  )) ;
    k=k+1;
 end
 
 % the last element in QOMVector_Oslo  is the mean of QOM from last_index
 % to end. To avoid misleading results, this is applied only if this rage
 % is longer than 5 seconds
        last_index = floor((i+window)*100);
        if ending > last_index/100  + 5
        QOMVector_Oslo(k)= mean(SmoothedComulativeParticipantsVector(last_index:floor(ending)*100));
        end
%         



%prepre x axis
seconds=(start+step:step:length(QOMVector_Oslo) * step);
%seconds_length= length(seconds)

   %  length_QOMVector_Oslo=length(QOMVector_Oslo)
     
    % in the following, we do not add step to ending because there is no zero pading. so if we do so, there will be more elements in the x axis than the y axis 
    %plot(seconds,normalize(QOMVector_Oslo,'range'),'b','linewidth',1.25,'DisplayName','Oslo QOM');
 

 
 


end

