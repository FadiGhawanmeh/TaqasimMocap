function [AmmanMatrix] = CreateAmmanMatrix(struct)

for i=1:33
    AmmanMatrix(:,i)=struct.(matlab.lang.makeValidName(strcat('Vector_',int2str(i))));
end

%33 means the matrix is not clean. Samples 5, 29,32 will be rejected later.
%imagesc(1:52060,1:30,myOsloMatrix');