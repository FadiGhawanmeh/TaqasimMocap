
% complexity ==1 , density == 2, register == 3 
curveChoise= 3;
switch curveChoise
    
    case 1
%plot complexity vector
ComplexityVec=getComplexityVector;
NC=normalize(ComplexityVec,'range');
seconds=(40:2:489.99);
NC(end)=[ ];NC(end)=[ ];NC(end)=[ ];
seconds(end)=[ ];seconds(end)=[ ];seconds(end)=[ ];
 plot(seconds,NC,'k','linewidth',1.25,'DisplayName','Melodic complixity');
 xlim([0 520])
 title('Elicit'' perceptual melodic complexity VS All participants'' comulative QOM in Amman and Oslo: 15s window, 2s step','FontSize', 14, 'FontWeight', 'bold')
 dispName='Melodic complixity';
 
    case 2
 % plot density vector
 densityVec = getDensityVector;
 ND=normalize(densityVec,'range');
 seconds=(40:2:489.99);
ND(end)=[ ];ND(end)=[ ];ND(end)=[ ];
seconds(end)=[ ];seconds(end)=[ ];seconds(end)=[ ];
  plot(seconds,ND,'k','linewidth',1.25,'DisplayName','Note density');
 xlim([0 520])
 title('Elicit'' note density VS All participants'' comulative QOM in Amman and Oslo: 15s window, 2s step','FontSize', 14, 'FontWeight', 'bold')
 dispName='Note density';

    case 3
        % plot register vector
  registerVec = getRegisterVector;
   NR=normalize(registerVec,'range');
    seconds=(40:2:489.99);
    NR(end)=[ ];NR(end)=[ ];NR(end)=[ ];
seconds(end)=[ ];seconds(end)=[ ];seconds(end)=[ ];
    
  plot(seconds,NR,'k','linewidth',1.25,'DisplayName','register (mean pitch)');
  xlim([0 520])
 title('Elicit'' register (mean pitch) VS All participants'' comulative QOM in Amman and Oslo: 5s window, 2s step','FontSize', 14, 'FontWeight', 'bold')
 dispName='register (mean pitch)';
end
 
 
 
hold on;
%plot normalized QOM vectors
QOMVector_Oslo = getQOMVector_Oslo;
start=0;
step=2;
Osloseconds=(start+step:step:length(QOMVector_Oslo) * step);

plot(Osloseconds,normalize(QOMVector_Oslo,'range'),'b','linewidth',1.25,'DisplayName','Oslo QOM');

QOMVector_Amman = getQOMVector_Amman;
Ammanseconds=(start+step:step:length(QOMVector_Amman) * step);

plot(Ammanseconds,normalize(QOMVector_Amman,'range'),'r','linewidth',1.25,'DisplayName','Amman QOM');


xlabel('Time (sec)', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('Normalized value', 'FontSize', 11, 'FontWeight', 'bold');

brown_green='#EDB120';
xline(171.5, '--','color',brown_green,'linewidth',2.5,'label','mod. start')
xline(412, '--','color',brown_green,'linewidth',2.5,'label','mod. end')

black='#000000';
xline(41, '--','color',black,'linewidth',2.5,'label','improv. start','DisplayName','')
xline(486, '--','color',black,'linewidth',2.5,'label','improv. end','DisplayName','')

green='#00FF00';
xline(304.65, '--','color',green,'linewidth',2.5,'label','perc. start')
xline(423.36, '--','color',green,'linewidth',2.5,'label','perc. end')

legend(dispName,'Oslo QOM','Amman QOM ','Location', 'Best')
