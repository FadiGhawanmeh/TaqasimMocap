%stop(player);

% modifed after import from https://stackoverflow.com/questions/12825092/in-matlab-how-can-i-sync-audio-with-a-plot

figure
   
StartCrop = 105 ;%30; %0
EndCrop   = 113; %171.5; %520.6


[y,fs] = audioread('elicitWithSilences.wav');
FullAudio=y;

%shiftRight audio, to make it late 1 second, because mocap response is already late
%for about one second
%shiftValue is made 0 because I decided to shiftLeftMocab rather than
%shiftRight audio, wav and pianoroll
ShiftValue= 0;
FullAudioRightShifted=[zeros(44100*ShiftValue,1)' FullAudio'];

y=FullAudioRightShifted;
% elicitAudio=load('elicitAudio.mat');
% y=elicitAudio.y;
% fs=elicitAudio.fs;


%25309 is for 0.5739 s difference to reach the length of OsloArrays 520.6 s 
y(length(y)+1:length(y)+25309)=zeros(25309,1);

%crop preparation
y= y(StartCrop*44100+1:EndCrop*44100);


durT=length(y)/fs;
%durT = 3; %seconds
%fs = 44100;
durS = fs*durT; %samples
x=y;
%x = randn(durS, 1);

dt = 1/fs;
tAxis = dt:dt:durT;

frameRate = 25; %fps original

frameT = 1/frameRate;

%mag = 1;
mag = 30;


%plot(tAxis, x);

PreviouslySavedWorkspace=load('IntenstyLimited3OsloMatrixDenoised50.mat');%previously saved workspace
%crop preparation
CroppedIntensistyLimited3OsloMatrixDenoised50=PreviouslySavedWorkspace.IntensistyLimited3OsloMatrixDenoised50(floor(StartCrop*100)+1:floor(EndCrop*100),:);
%imagesc(tAxis,1:30,IntensistyLimited3OsloMatrixDenoised50');
%imagesc(floor(StartCrop*100)+1:floor(EndCrop*100),1:30,CroppedIntensistyLimited3OsloMatrixDenoised50');

ComulativeParticipantsVector = AllParticipantsQOM(CroppedIntensistyLimited3OsloMatrixDenoised50);

%smooth the signal
 SmoothedComulativeParticipantsVector=movavg(ComulativeParticipantsVector,'simple',50) ;

%seconds= (floor(StartCrop*100)+1:1:floor(EndCrop*100));
seconds= (StartCrop:0.01:EndCrop);
seconds=seconds(1:length(seconds)-1); %make same length with participants vector
%length(seconds)
%length(seconds)
%seconds=seconds(1:length(ComulativeParticipantsVector));



FullAudioSqueezed=FullAudio/10;   %let audio and mocap have comparable amplitude
FullAudioSeconds= (StartCrop:1/44100.0:EndCrop);
FullAudioSeconds= FullAudioSeconds(1:length(FullAudioSeconds)-1);

FullAudioSecondsRightShifted=FullAudioSeconds+ShiftValue;

plot(FullAudioSecondsRightShifted,FullAudioSqueezed(floor(StartCrop*44100)+1:floor(EndCrop*44100)),'b');
title('Smoothed comulative QOM (all particimants in Oslo), limited 3 denoized 0.5 normalized');
hold on

MocapShift= 0;%.75;
seconds = seconds - MocapShift;
 plot(seconds,SmoothedComulativeParticipantsVector,'r','LineWidth',1.10)


%ylim([-mag mag])
ylim([0 .1125])

%ylim([0 .060])


%xlim([0 durT])
%xlim([floor(StartCrop*100)+1 floor(EndCrop*100)+100])
%xlim([StartCrop EndCrop+0.5])
xlim([StartCrop-1 EndCrop+0.5])

%xlim([StartCrop EndCrop])


xlabel('Time [s]')
ylabel('Participants')

%playHeadLoc = 0;
%playHeadLoc = floor(StartCrop*100)+1;
playHeadLoc = StartCrop;

%hold on; ax = plot([playHeadLoc playHeadLoc], [-mag mag], 'r', 'LineWidth', 2);
hold on; ax = plot([playHeadLoc playHeadLoc], [0 30], 'r', 'LineWidth', 2);

myStruct.playHeadLoc = playHeadLoc;
%pause(13.25)  % i guess this is useless... just try to reduce load on CPU and hope that audio and graphics be in sinc
player = audioplayer(x, fs);

myStruct.frameT = frameT;
myStruct.ax = ax;

set(player, 'UserData', myStruct);
set(player, 'TimerFcn', @apCallback);
set(player, 'TimerPeriod', frameT);
play(player);

%to stop it, write: stop (player)


