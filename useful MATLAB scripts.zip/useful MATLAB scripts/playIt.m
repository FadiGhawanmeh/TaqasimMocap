function [] = playIt()

% modifed after import from https://stackoverflow.com/questions/12825092/in-matlab-how-can-i-sync-audio-with-a-plot

[y,fs] = audioread('elicitWithSilences.wav');
%adjust length precisely: add silence of approximately .04 seconds
y(length(y)+1:length(y)+1495)=zeros(1495,1);


durT=length(y)/fs;
%durT = 3; %seconds
%fs = 44100;
durS = fs*durT; %samples
x=y;
%x = randn(durS, 1);

dt = 1/fs;
tAxis = dt:dt:durT;

frameRate = 25; %fps
frameT = 1/frameRate;

mag = 5;

figure;
plot(tAxis, x);
ylim([-mag mag])
xlim([0 durT])
xlabel('Time [s]')

playHeadLoc = 0;
hold on; ax = plot([playHeadLoc playHeadLoc], [-mag mag], 'r', 'LineWidth', 2);

player = audioplayer(x, fs);
myStruct.playHeadLoc = playHeadLoc;
myStruct.frameT = frameT;
myStruct.ax = ax;

set(player, 'UserData', myStruct);
set(player, 'TimerFcn', @apCallback);
set(player, 'TimerPeriod', frameT);
play(player);

end


