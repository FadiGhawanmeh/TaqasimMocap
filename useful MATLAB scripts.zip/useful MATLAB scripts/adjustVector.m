function [adjustedVector] = adjustVector(vector)


adjustedVector = zeros(52060,1);

if length(vector)<52060
   adjustedVector= [vector ;zeros(52060-length(vector),1)]; 
elseif length(vector) > 52060

thePlus= length(vector)-52060;
thePlusBeg= floor ( thePlus * (1/3));
thePlusEnd=thePlus - thePlusBeg;
adjustedVector= vector(thePlusBeg+1: length(vector)-thePlusEnd);

end 





end

