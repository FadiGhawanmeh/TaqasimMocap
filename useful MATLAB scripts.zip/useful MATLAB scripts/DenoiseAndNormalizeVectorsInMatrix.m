function [DenoisedAndNormalizedMatrix]= DenoiseAndNormalizeVectorsInMatrix(Matrix, NoiseLevel)
% By Fadi AL-Ghawanmeh on July 18, 2022
% Matrix is the mocap vectors matrix: each vector in a colomn 
% this function is better applied after applying LimitIntensitiesInMatrix

DenoisedAndNormalizedMatrix=Matrix;

[rows columns]=size(DenoisedAndNormalizedMatrix);


for i=1:columns
 
    %denoise(noise in the slide ranges usually between .25 and 0.75, mostly .5)
    DenoisedAndNormalizedMatrix(:,i)=DenoisedAndNormalizedMatrix(:,i)- NoiseLevel;
    for j=1:rows
    if DenoisedAndNormalizedMatrix(j,i)<0 
        DenoisedAndNormalizedMatrix(j,i)=0;
    end
    end
    
    %mormalize
%DenoisedAndNormalizedMatrix(:,i)= DenoisedAndNormalizedMatrix(:,i)/max(DenoisedAndNormalizedMatrix(:,i));

end


