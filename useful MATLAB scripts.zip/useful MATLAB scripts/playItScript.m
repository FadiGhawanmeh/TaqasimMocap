%stop(player);

% modifed after import from https://stackoverflow.com/questions/12825092/in-matlab-how-can-i-sync-audio-with-a-plot

%30583

%load the audio file before starting the analysis session (outside this
%script) because it takes long time in the background!!!!

% 118.760    
StartCrop = 30; %0
EndCrop   = 171.5; %520.6



% based on the above, I will crop (y) in the audio file
% and also column length in IntensistyLimited3OsloMatrixDenoised50
%    y= y(StartCrop:EndCrop);
% CroppedIntensistyLimited3OsloMatrixDenoised50=
% PreviouslySavedWorkspace.IntensistyLimited3OsloMatrixDenoised50(StartCrop:EndCrop,:);


[y,fs] = audioread('elicitWithSilences.wav');

% elicitAudio=load('elicitAudio.mat');
% y=elicitAudio.y;
% fs=elicitAudio.fs;



%adjust length precisely: add silence of approximately .04 seconds
%y(length(y)+1:length(y)+1495)=zeros(1495,1);

%25309 is for 0.5739 s difference to reach the length of OsloArrays 520.6 s 
y(length(y)+1:length(y)+25309)=zeros(25309,1);



%crop preparation
y= y(StartCrop*44100+1:EndCrop*44100);



durT=length(y)/fs;
%durT = 3; %seconds
%fs = 44100;
durS = fs*durT; %samples
x=y;
%x = randn(durS, 1);

dt = 1/fs;
tAxis = dt:dt:durT;

%frameRate = 25; %fps original

%frameRate = 250; %fps 

frameRate = 25; %fps

%frameRate = 100*100; % multiplied by SR of motion capture data

frameT = 1/frameRate;

%mag = 1;
mag = 30;

figure;
%plot(tAxis, x);

PreviouslySavedWorkspace=load('IntenstyLimited3OsloMatrixDenoised50.mat');%previously saved workspace
%IntensistyLimited3OsloMatrixDenoised50=PreviouslySavedWorkspace.IntensistyLimited3OsloMatrixDenoised50;
%%imagesc(1:52060,1:30,IntensistyLimited3OsloMatrixDenoised50');
%imagesc(tAxis,1:30,IntensistyLimited3OsloMatrixDenoised50');

%crop preparation
CroppedIntensistyLimited3OsloMatrixDenoised50=PreviouslySavedWorkspace.IntensistyLimited3OsloMatrixDenoised50(floor(StartCrop*100)+1:floor(EndCrop*100),:);
%imagesc(tAxis,1:30,IntensistyLimited3OsloMatrixDenoised50');
imagesc(floor(StartCrop*100)+1:floor(EndCrop*100),1:30,CroppedIntensistyLimited3OsloMatrixDenoised50');


title('limited 3 denoized 0.5 normalized');


%ylim([-mag mag])
ylim([0.5 30])
%xlim([0 durT])
xlim([floor(StartCrop*100)+1 floor(EndCrop*100)+100])

%xlim([StartCrop EndCrop])


xlabel('Time [s]')
ylabel('Participants')

%playHeadLoc = 0;
playHeadLoc = floor(StartCrop*100)+1;
%hold on; ax = plot([playHeadLoc playHeadLoc], [-mag mag], 'r', 'LineWidth', 2);
hold on; ax = plot([playHeadLoc playHeadLoc], [0 30], 'r', 'LineWidth', 2);

myStruct.playHeadLoc = playHeadLoc;
%pause(13.25)  % i guess this is useless... just try to reduce load on CPU and hope that audio and graphics be in sinc
player = audioplayer(x, fs);

myStruct.frameT = frameT;
myStruct.ax = ax;

set(player, 'UserData', myStruct);
set(player, 'TimerFcn', @apCallback);
set(player, 'TimerPeriod', frameT);
play(player);




