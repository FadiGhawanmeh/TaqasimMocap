StartCrop = 0; 
EndCrop   = 520.6;

figure

subplot(2,1,1)
PreviouslySavedWorkspace=load('IntenstyLimited3OsloMatrixDenoised50.mat');%previously saved workspace

CroppedIntensistyLimited3OsloMatrixDenoised50=PreviouslySavedWorkspace.IntensistyLimited3OsloMatrixDenoised50(floor(StartCrop*100)+1:floor(EndCrop*100),:);

imagesc(floor(StartCrop*100)+1:floor(EndCrop*100),1:30,CroppedIntensistyLimited3OsloMatrixDenoised50');

title('QOM of Oslo participants : limited 3 denoized 0.5 normalized');
xlabel('Time [s]')
ylabel('Participants')

subplot(2,1,2)
PreviouslySavedWorkspace=load('IntenstyLimited3AmmanMatrixDenoised50.mat');%previously saved workspace
CroppedIntensistyLimited3AmmanMatrixDenoised50=PreviouslySavedWorkspace.Denoised5NormalizedIntensityLimited3AmmanMatrix33(floor(StartCrop*100)+1:floor(EndCrop*100),:);
imagesc(floor(StartCrop*100)+1:floor(EndCrop*100),1:33,CroppedIntensistyLimited3AmmanMatrixDenoised50');
title('QOM of Amman participants : limited 3 denoized 0.5 normalized');
xlabel('Time [s]')
ylabel('Participants')  
