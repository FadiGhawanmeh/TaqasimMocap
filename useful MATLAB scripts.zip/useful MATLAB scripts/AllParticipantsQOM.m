function [ParticipantsVector] = AllParticipantsQOM(ParticipantsMatrix)
%UNTITLED Summary of this function goes here
%   27 July, 2022

[rows columns]= size(ParticipantsMatrix);

ParticipantsVector=zeros(rows,1);

for i=1:rows
    ParticipantsVector(i,1)=sum(ParticipantsMatrix(i,:))/columns;
end

