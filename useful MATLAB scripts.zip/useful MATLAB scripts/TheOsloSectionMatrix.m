function [osloSectionMatrix] = TheOsloSectionMatrix(LimitingValue)
%Fadi Al-Ghawanmeh April 10, 2023
% create sectionMatrix that include, for each participant, the average
% movement persection

%  start=1; theEnd=4099;  disp('sec.0')
%  start=4100; theEnd=17100;  disp('sec.1')
% start=17300; theEnd=30300;  disp('sec.2')   
%  start=30400; theEnd=42300;  disp('sec.3')
% start=42700; theEnd=48600;  disp('sec.4')   
% start=48700; theEnd=52060;  disp('sec.5')   
% start=3100; theEnd=48600;  disp('all improvisation')      


Matrices=load('C:\Users\fadig\Desktop\main experiment Oslo\Oslo clean signals\background detection\IntensityLimited3AmmanMatrixDenoised5_new_and_Oslo.mat');
RawOsloMatrix=Matrices.IntensityLimited3OsloMatrixDenoised5_new;

OsloMatrix=LimitIntensitiesInMatrix(RawOsloMatrix, LimitingValue);

for i=1:30
        osloSectionMatrix(1,i)= mean(OsloMatrix(1:4099,i));
        osloSectionMatrix(2,i)= mean(OsloMatrix(4100:17100,i));
        osloSectionMatrix(3,i)= mean(OsloMatrix(17300:30300,i));
        osloSectionMatrix(4,i)= mean(OsloMatrix(30400:42300,i));
        osloSectionMatrix(5,i)= mean(OsloMatrix(42700:48600,i));
        osloSectionMatrix(6,i)= mean(OsloMatrix(48700:52060,i));
        osloSectionMatrix(7,i)= mean(OsloMatrix(3102:48600,i));
end


end

