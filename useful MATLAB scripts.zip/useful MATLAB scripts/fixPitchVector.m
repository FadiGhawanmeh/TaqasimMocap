function [fixedPitchVector] = fixPitchVector(PitchVector)
% Fadi Al-Ghawanmeh, in Aug. 12, 2022
% this function is applied on the melodic pitch vector, it filters out the qarar note (the note but an octave lower) that is usually used as an ornament
% after the performed note

if length(PitchVector~=0)

fixedPitchVector(1)=PitchVector(1);
    counter=2;
    for j=2:length(PitchVector)
        if PitchVector(j)~=PitchVector(j-1)-12
        fixedPitchVector(counter)=PitchVector(j);
        counter=counter+1;  
        end
    end

else
    fixedPitchVector= [ ];
end

end

