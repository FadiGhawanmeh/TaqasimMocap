function [OsloMatrix] = CreateOsloMatrix(struct)

for i=1:30
    OsloMatrix(:,i)=struct.(matlab.lang.makeValidName(strcat('Vector_',int2str(i))));
end


%imagesc(1:52060,1:30,myOsloMatrix');