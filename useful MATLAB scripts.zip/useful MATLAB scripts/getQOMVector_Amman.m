function [QOMVector_Amman] = getQOMVector_Amman
%Fadi Al-Ghawanmeh August 14,2022

%get quantity of motion vector for all participants in Amman using
%AllParticipantsQOM victor. The quantity of motion vector is calculated on
%a "window" that is moving by a "step".

%for the silence at the end (490-520).
%create its own  QOM elements. you may take it each 5 seconds, then
%smooth the whole period to 10 second.

% answers
window=20;%10;
step=2;%15;%5;
k=1;  % counter for registerVec
%start and end in seconds
start=     0;
ending= 520;%489.99; 
PreviouslySavedWorkspace=load('IntenstyLimited3AmmanMatrixDenoised50.mat');%previously saved workspace
%crop preparation
CroppedIntensistyLimited3AmmanMatrixDenoised50=PreviouslySavedWorkspace.Denoised5NormalizedIntensityLimited3AmmanMatrix33(floor(start*100)+1:floor(ending*100),:);
ComulativeParticipantsVector = AllParticipantsQOM(CroppedIntensistyLimited3AmmanMatrixDenoised50);
%smooth the signal
 SmoothedComulativeParticipantsVector=movavg(ComulativeParticipantsVector,'simple',50) ;

 %LengthOfSmoothedComulativeParticipantsVector= length(SmoothedComulativeParticipantsVector)
  
 for i=start:step:(ending-window) 
  %   floor((i+window)*100)
    QOMVector_Amman(k)= mean(SmoothedComulativeParticipantsVector(floor(i*100)+1:  floor((i+window)*100)  )) ;
    k=k+1;
 end
 
 % the last element in QOMVector_Amman  is the mean of QOM from last_index
 % to end. To avoid misleading results, this is applied only if this rage
 % is longer than 5 seconds
        last_index = floor((i+window)*100);
        if ending > last_index/100  + 5
        QOMVector_Amman(k)= mean(SmoothedComulativeParticipantsVector(last_index:floor(ending)*100));
        end
%         



%prepre x axis
seconds=(start+step:step:length(QOMVector_Amman) * step);
%seconds_length= length(seconds)

%     length_QOMVector_Amman=length(QOMVector_Amman)
     
    % in the following, we do not add step to ending because there is no zero pading. so if we do so, there will be more elements in the x axis than the y axis 
    %plot(seconds,normalize(QOMVector_Amman,'range'),'r','linewidth',1.25,'DisplayName','Amman QOM');
 

 
 


end

