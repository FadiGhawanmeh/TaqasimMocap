function src = apCallback(src, eventdata)
    myStruct = get(src, 'UserData'); %//Unwrap

    
      % when 152.9052  headlook is more by 7.5%
    newPlayHeadLoc = ...
        myStruct.playHeadLoc + ...
           myStruct.frameT;
      %  myStruct.frameT *100.0;
     

%      newPlayHeadLoc = ...
%         myStruct.playHeadLoc + ...
%         myStruct.frameT;
    
    %%%make up for mocap SR (100), so add 99 for the value (it originally increases by
    %%%one each time, so by adding 99 it becomes 100, i.e. one second)
    %newPlayHeadLoc
    %newPlayHeadLoc
    %newPlayHeadLoc=newPlayHeadLoc+99;
    %newPlayHeadLoc=newPlayHeadLoc+4  ;  % +  1/length of selected audio in second   %   - 1/length of selected audio in second
  %  newPlayHeadLoc=newPlayHeadLoc +.4*3  ;  % .4  =  100/250  ; mocapSR/FrameRate
    %%%
    
    %DO NOT IGNORE THIS SENTENCE myStruct.frameT
    
    set(myStruct.ax, 'Xdata', [newPlayHeadLoc newPlayHeadLoc])

    myStruct.playHeadLoc = newPlayHeadLoc;
    set(src, 'UserData', myStruct); %//Rewrap
end